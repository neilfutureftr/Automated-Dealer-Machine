const anchor = require("@project-serum/anchor");

const Token = require("@project-serum/associated-token");
const assert = require("assert");
const { SystemProgram } = anchor.web3;
const { PublicKey } = anchor.web3;
const {
  TOKEN_PROGRAM_ID,
  sleep,
  getTokenAccount,
  createMint,
  createTokenAccount,
} = require("./utils");
process.env.ANCHOR_WALLET="/root/.config/solana/id.json"
process.env.ANCHOR_PROVIDER_URL="https://api.testnet.solana.com"

let provider=anchor.Provider.env();
anchor.setProvider(provider);
const idl = JSON.parse(require('fs').readFileSync('../target/idl/ftrDistributor.json', 'utf8'));
const pk_userUsdc=new anchor.web3.PublicKey(require('fs').readFileSync('userUsdc_pk.txt', 'utf8'));
const pk_poolUsdc=new anchor.web3.PublicKey(require('fs').readFileSync('poolUsdc_pk.txt', 'utf8'));
const pk_userFtr=new anchor.web3.PublicKey(require('fs').readFileSync('userFtr_pk.txt', 'utf8'));
const pk_poolFtr=new anchor.web3.PublicKey(require('fs').readFileSync('poolFtr_pk.txt', 'utf8'));
const pk_userFixedRate=new anchor.web3.PublicKey(require('fs').readFileSync('userFixedRate_pk.txt', 'utf8'));
const pk_poolFixedRate=new anchor.web3.PublicKey(require('fs').readFileSync('poolFixedRate_pk.txt', 'utf8'));

// Address of the deployed pr
const programId = new anchor.web3.PublicKey('D6CJs1GE1MZqEV4kGnbWzvYJUDnQQ9iyEnpk4LdgQuBq');
const program = new anchor.Program(idl, programId);
// Configure the client to use the local cluster.
// Configure the client to use the local cluster.



async function main(){

  const pk_ftrMint=new anchor.web3.PublicKey(require('fs').readFileSync('ftrMint_pk.txt', 'utf8'));
  const pk_usdMint=new anchor.web3.PublicKey(require('fs').readFileSync('usdcMint_pk.txt', 'utf8'));
  const pk_fixedRateMint=new anchor.web3.PublicKey(require('fs').readFileSync('fixedRateMint_pk.txt', 'utf8'));
  const pk_poolAccount=new anchor.web3.PublicKey(require('fs').readFileSync('poolAccount_pk.txt', 'utf8'));

 const pk_poolSignerAccount=new anchor.web3.PublicKey(require('fs').readFileSync('poolSignerAccount_pk.txt', 'utf8'));


//poolUsdc token account
//DWBjLmKmE4FUQmMZnToi88QgFqvD9uswER4F2VAGWbGV
//D7GmCCjB5kMzYvAeoACALvHv4bvqDAAw1vbLbQ8stRi9
  
  let ftrMint = pk_ftrMint;
  let usdcMint = pk_usdMint;

  let fixedRateMint = pk_fixedRateMint;
  let poolAccountPK= pk_poolAccount;


if(false){
  poolFtr = await Token.getAssociatedTokenAddress(pk_poolSignerAccount, pk_ftrMint);
  userFtr = await Token.getAssociatedTokenAddress(provider.wallet.publicKey, pk_ftrMint);

  poolUsdc = await Token.getAssociatedTokenAddress(pk_poolSignerAccount, pk_usdMint);
  userUsdc = await Token.getAssociatedTokenAddress(provider.wallet.publicKey, pk_usdMint);

  poolFixedRate = await Token.getAssociatedTokenAddress(pk_poolSignerAccount, pk_fixedRateMint);
  userFixedRate = await Token.getAssociatedTokenAddress(provider.wallet.publicKey, pk_fixedRateMint);
  console.log("Final_check")
}


if(true){
  poolFtr = pk_poolFtr
  userFtr = pk_userFtr
  poolUsdc = pk_poolUsdc
  userUsdc = pk_userUsdc
  poolFixedRate = pk_poolFixedRate
  userFixedRate = pk_userFixedRate
  console.log("Final_check")
}


if (false){
  poolFtr = await getTokenAccount(provider, pk_poolFtr);
  console.log(poolFtr)
  userFtr = await getTokenAccount(provider, pk_userFtr);
  console.log(userFtr)

  poolUsdc = await getTokenAccount(provider, pk_poolUsdc);
  console.log(poolUsdc)
  userUsdc = await getTokenAccount(provider, pk_userUsdc);
  console.log(userUsdc)
  poolFixedRate = await getTokenAccount(provider, pk_poolFixedRate);
  console.log(poolFixedRate)
  userFixedRate = await getTokenAccount(provider, pk_userFixedRate);
  console.log(userFixedRate)
}

//console.log(ftrMint.toString())

let authority=provider.wallet.publicKey;

const [user, bump] = await PublicKey.findProgramAddress(
      [authority.toBuffer()],
      program.programId
    );

console.log("Trying to created user ");
if (false){
await program.rpc.createUser( bump, {
      accounts: {
        user,
        authority,
        systemProgram: anchor.web3.SystemProgram.programId,
      },
    });
 console.log("Successfully created user ");
}else{
  console.log("User was already created ");
}

  const [_poolSigner, nonce] = await anchor.web3.PublicKey.findProgramAddress(
    [fixedRateMint.toBuffer()],
    program.programId
  );
 poolSigner=_poolSigner;

const account = await program.account.user.fetch(user);

const initial_FTR_in_account = new anchor.BN(100);
const initial_USDC_in_account = new anchor.BN(1_000);
const initial_FR_in_pool = new anchor.BN(100);






console.log("Changing prices");


const maturity_time=new anchor.BN(23_000_672);
const maturity_price=new anchor.BN(23_000_672);


const ftr_per_contract=new anchor.BN(1);
const fixed_rate_price=new anchor.BN(102);
creatorUsdc=userUsdc;
creatorFtr=userFtr;
creatorFixedRate=userFixedRate;



try{
await program.rpc.updatePriceNdCo(ftr_per_contract,fixed_rate_price,maturity_time,maturity_price,{
    accounts: {
    poolAccount: poolAccountPK,
    creatorAuthority: provider.wallet.publicKey,
    poolSigner,
    user,

    poolUsdc,
    poolFtr,
    poolFixedRate,
    creatorUsdc,
    creatorFtr,
    creatorFixedRate,
    tokenProgram: TOKEN_PROGRAM_ID,
    clock: anchor.web3.SYSVAR_CLOCK_PUBKEY,
  },

  }

  )
  console.log("Updating prices succeed");
    } catch (err) {
      console.log("This is the error message", err.toString());
    }


const poolAccount_l = await program.account.poolAccount.fetch(poolAccountPK);

console.log("Purchasing")




poolFtrAccount = await getTokenAccount(provider, poolFtr);
userFtrAccount = await getTokenAccount(provider, userFtr);

poolUsdcAccount = await getTokenAccount(provider, poolUsdc);
userUsdcAccount = await getTokenAccount(provider, userUsdc);

poolFixedRateAccount = await getTokenAccount(provider, poolFixedRate);
userFixedRateAccount = await getTokenAccount(provider, userFixedRate);

console.log("USDC in the USDC pool")
console.log(poolUsdcAccount.amount.toString());
console.log("FTR in the FTR pool")
console.log(poolFtrAccount.amount.toString());
console.log("FixedRate in the FixedRate pool")
console.log(poolFixedRateAccount.amount.toString().toString());

console.log("USDC in the user USDC wallet")
console.log(userUsdcAccount.amount.toString())
console.log("FTR in the user FTR wallet")
console.log(userFtrAccount.amount.toString())
console.log("FixedRate in the user FixedRate wallet")
console.log(userFixedRateAccount.amount.toString())
console.log("----------PURCHASING 1.2 FIXED RATE -----------")
const expected_usdc_to_spend=new anchor.BN("126");
const expected_FR_to_receive=new anchor.BN("2");
const expected_FTR_to_send=new anchor.BN(1_604);

try{
await program.rpc.getFixedRate(
    expected_usdc_to_spend,
    expected_FTR_to_send,
    expected_FR_to_receive,{
    accounts: {

    poolAccount: poolAccountPK,
    userAuthority: provider.wallet.publicKey,
    poolSigner,
    user,

    poolUsdc,
    poolFtr,
    poolFixedRate,
    userUsdc,
    userFtr,
    userFixedRate,
    tokenProgram: TOKEN_PROGRAM_ID,
    clock: anchor.web3.SYSVAR_CLOCK_PUBKEY,
  },

  }

  )

    } catch (err) {
      console.log("This is the error message", err.toString());
    }
poolFtrAccount = await getTokenAccount(provider, pk_poolFtr);
userFtrAccount = await getTokenAccount(provider, pk_userFtr);

poolUsdcAccount = await getTokenAccount(provider, pk_poolUsdc);
userUsdcAccount = await getTokenAccount(provider, pk_userUsdc);

poolFixedRateAccount = await getTokenAccount(provider, pk_poolFixedRate);
userFixedRateAccount = await getTokenAccount(provider, pk_userFixedRate);

console.log("----------CHECKING STATES FIXED RATE -----------")
console.log("USDC in the USDC pool")
console.log(poolUsdcAccount.amount.toString());
console.log("FTR in the FTR pool")
console.log(poolFtrAccount.amount.toString());
console.log("FixedRate in the FixedRate pool")
console.log(poolFixedRateAccount.amount.toString());

console.log("USDC in the user USDC wallet")
console.log(userUsdcAccount.amount.toString())
console.log("FTR in the user FTR wallet".toString())
console.log(userFtrAccount.amount)
console.log("FixedRate in the user FixedRate wallet")
console.log(userFixedRateAccount.amount.toString())

console.log("-------------Redeeming Fixed Rate-----------")
const extract = new anchor.BN(1);
try{
await program.rpc.redeemFixedRate(extract,{
    accounts: {
    poolAccount: poolAccountPK,
    
    poolSigner,
    
    userAuthority: provider.wallet.publicKey,
    user,
    poolFtr,
    poolFixedRate,
    poolUsdc,
    userFtr,
    userUsdc,
    userFixedRate,
    tokenProgram: TOKEN_PROGRAM_ID,
    clock: anchor.web3.SYSVAR_CLOCK_PUBKEY,
  },

  }

  )

    } catch (err) {
      console.log("This is the error message", err.toString());
    }
poolFtrAccount = await getTokenAccount(provider, pk_poolFtr);
userFtrAccount = await getTokenAccount(provider, pk_userFtr);

poolUsdcAccount = await getTokenAccount(provider, pk_poolUsdc);
userUsdcAccount = await getTokenAccount(provider, pk_userUsdc);

poolFixedRateAccount = await getTokenAccount(provider, pk_poolFixedRate);
userFixedRateAccount = await getTokenAccount(provider, pk_userFixedRate);

console.log("----------CHECKING STATES FIXED RATE -----------")
console.log("USDC in the USDC pool")
console.log(poolUsdcAccount.amount.toString());
console.log("FTR in the FTR pool")
console.log(poolFtrAccount.amount.toString());
console.log("FixedRate in the FixedRate pool")
console.log(poolFixedRateAccount.amount.toString());

console.log("USDC in the user USDC wallet")
console.log(userUsdcAccount.amount.toString())
console.log("FTR in the user FTR wallet")
console.log(userFtrAccount.amount.toString())
console.log("FixedRate in the user FixedRate wallet")
console.log(userFixedRateAccount.amount.toString())





}
main();

